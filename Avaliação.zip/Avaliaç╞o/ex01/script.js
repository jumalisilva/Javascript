// 01 - Escreva um programa que solicite ao usuário que informe o seu nome completo utilizando a função prompt. Em seguida, exiba uma mensagem de alerta contendo o seguinte texto: "Olá [NOME DO USUÁRIO], seja bem-vindo!". 

let nome = prompt("Digite seu nome completo:");

alert(`Olá ${nome}, seja bem-vindo!`);