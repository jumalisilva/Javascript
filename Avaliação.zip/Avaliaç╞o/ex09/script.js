// 09 - Imagine que você precisa calcular a potência de um número. Escreva uma função chamada "potencia" que recebe dois parâmetros, "a" e "b". A função deve calcular e retornar o valor de "a" elevado à "b" potência. Para calcular a potência, você pode utilizar o operador de exponenciação "**" ou a função "Math.pow(a, b)". Em seguida, chame a função "potencia" quatro vezes com diferentes valores para "a" e "b": (2,2), (3,2), (4,4) e (5,2). Exiba o resultado de cada chamada no console utilizando o método "console.log()". 

// let potencia = Math.pow(a,b);

let potencia1 = Math.pow(2,2);
let potencia2 = Math.pow(3,2);
let potencia3 = Math.pow(4,4);
let potencia4 = Math.pow(5,2);

console.log(potencia1);
console.log(potencia2);
console.log(potencia3);
console.log(potencia4);